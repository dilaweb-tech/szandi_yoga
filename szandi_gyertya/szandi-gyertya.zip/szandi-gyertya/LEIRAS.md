# Szandi gyertya – beillesztési leírás

Egy égő gyertya a Szandi Yoga oldalra, az oldal illusztrációjának stílusában
(lapos tónusok, fekete tus-kontúr, a rajz palettája). Blenderben készült 3D render,
a láng egy képsorból (sprite) lobog. Kép + CSS, JavaScript nincs.

Ez váltja a régi, tisztán CSS-es „ÉLŐ GYERTYA”-t (SVG data-URI maszkok a `pv.css`-ben).
A doboz ugyanaz a négyzet, és a gyertya ugyanott ül benne, mint a régiben →
a régi helyére cserélhető, az elrendezésen nem kell állítani.

## A csomag

```
szandi-gyertya/
  LEIRAS.md            ez a fájl
  bemutato.html        működő minta – böngészőben megnyitva így kell kinéznie
  gyertya.css          a teljes gyertya-CSS, egy blokk
  images/
    gyertya.webp       gyertyatest a tállal, átlátszó háttér, 1024×1024 (23 KB)
    gyertya-lang.webp  a láng 64 képkockája, 8×8-as rács, átlátszó háttér (132 KB)
  forras/              NEM kerül a weboldalra – csak újrarendereléshez
    gyertya_blender.py a Blender-jelenet kódból (Blender 5.2, Cycles)
    gyertya.blend      ugyanez megnyitható fájlként
    lang.json          a láng helye a dobozban – ebből jönnek a CSS számai
    elonezet.png       állókép referenciának
```

## Beillesztés – lépések

1. **Képek:** `images/gyertya.webp` és `images/gyertya-lang.webp` → az oldal `images/`
   mappájába.
2. **CSS:** a `gyertya.css` tartalmát másold be az oldal stíluslapjába (Szandinál
   `pv.css`), vagy linkeld külön fájlként. **Az `url()` útvonal a CSS-fájlhoz képest
   relatív.** Ha a CSS nem a gyökérben van, igazítsd a két `url("images/…")`-t.
3. **Markup:** a régi gyertya helyére:
   ```html
   <div class="candle" role="img" aria-label="Égő gyertya rózsaszín kerámiatálban, lobogó lánggal">
     <i class="candle__body"></i>
     <span class="candle__flame"></span>
   </div>
   ```
   Ha a gyertya csak díszítés (háttérelem), akkor `role="img"` és `aria-label` helyett
   `aria-hidden="true"` kell.
4. **A régi gyertya eltávolítása:** a `pv.css`-ben az „ÉLŐ GYERTYA” blokk, a
   `--sv-flame`, `--sv-flame-live`, `--sv-candle-body`, `--sv-candle-detail` változók,
   a `--pv-candle-*` / `--pv-flame-o` tokenek, és a `pv-flame-lick`, `pv-flame-sway`,
   `pv-flame-light` keyframe-ek. Előbb greppelj: csak azt töröld, amit máshol nem használ
   semmi. (A „Cukrászda” preset saját gyertyalángja más elem, azt ne bántsd.)
   Ha az osztálynevek ütköznek a régivel (`.candle`, `.candle__body`, `.candle__flame`),
   a régi szabályok törlése kötelező, különben összeakadnak.
5. **Méret:** csak a `.candle { width: … }` értéket állítsd. Minden más a doboz
   %-a, magától skálázódik. Az `aspect-ratio: 1` marad.

## Amihez ne nyúlj

- **A `.candle__flame` `left / top / width / height` értékei és a `transform-origin`**
  a renderből jönnek (`forras/lang.json`). Ha kézzel állítod, a láng lecsúszik a kanócról.
- **A sprite léptetése:** a `::before` 800%×800%-os, és két független lépő animáció viszi
  (`translate` = oszlop, `transform` = sor). Szándékosan nem `background-position`: a projekt
  szabálya, hogy csak `transform` és `opacity` mozogjon. A `steps(8)` és az időzítés
  (`8s/24`, `64s/24`) a 64 kockából és a 24 fps-ből jön.
- **Csökkentett mozgás:** `prefers-reduced-motion: reduce` esetén minden animáció áll,
  és az 1. képkocka látszik. Ez maradjon.
- **Egy oldalon egy hangsúlyos animáció** (projekt-szabály). Ha a gyertya mellett van
  más feltűnő mozgás (pl. hero-háttér), azt egyeztesd.
- **`forras/` ne kerüljön a docrootba.** A tárhelyen a docroot git munkapéldány; a
  `.blend` és a `.py` belső forrás, nem lehet letölthető.

## Ellenőrzés beillesztés után

- A láng a kanócon ül, a töve a gyertya pereme mögé bújik (nem lóg rá a peremre).
- A lángban soha nem villan be a szomszéd képkocka széle.
- Mobilon (375 px) nincs vízszintes görgetés; a doboz `min(86vw, …)`.
- A DevTools „Emulate prefers-reduced-motion” beállítással a láng áll.
- A két kép 200-zal jön le (útvonal-hiba esetén üres a doboz).

## Módosítás / újrarenderelés (csak ha kell)

Blender 5.2, a `forras/` mappából:

```bash
blender -b --factory-startup --python gyertya_blender.py -- mode=body res=1024 samples=32
blender -b --factory-startup --python gyertya_blender.py -- mode=flame res=1024 frames=64 samples=24
blender -b --factory-startup --python gyertya_blender.py -- mode=preview res=700
```

- A kimenet a `forras/img/` mappába kerül. Onnan másold az oldal `images/` mappájába.
- **Színek:** a script elején (`WAX`, `DRIP`, `POOL`, `DISH`, `FLAME`, `INK`) hex kódokban.
  A render emissziós, a „Standard” nézet miatt a hex pontosan az marad a képen.
  A CSS-ből a színek nem cserélhetők, csak újrarendereléssel.
- **Ha a láng újra lett renderelve**, a CSS számait frissíteni kell az új `lang.json`-ból:
  - `left`, `top`, `width`, `height` → egy az egyben %-ként;
  - `transform-origin` y = `(base_y − top) / height × 100%`;
  - `frames` / `fps` változásakor a két animáció ideje és a `steps()` is változik.
- **Kamera és kompozíció** (12°-os rálátás, 120 mm, a doboz 24,7 cm széles) a régi
  CSS-gyertyához van igazítva. Ha változik, mindkét képet és a CSS számait is újra kell
  generálni.
- **A csorgások** külön testek a falon (`DRIPS` lista: szög, hossz, szélesség, vastagság).
  Így a kontúrjuk sima.
